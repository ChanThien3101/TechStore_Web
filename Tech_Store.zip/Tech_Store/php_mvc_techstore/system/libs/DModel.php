<?php
class DModel{
   protected $db = array();
   public function __construct(){
       $connect = 'mysql:dbname=php_mvc_pdo_techstore; host=localhost; charset=utf8';
       $user = 'dinhhuuduc3101';
       $pass = 'songdeyeuthuong2002';
       $this ->db = new Database($connect,$user,$pass);
    }
    
}
?>