
<section>
	<div class="bg_in">
		<div class="module_pro_all">
			<div class="box-title">
				<div class="title-bar">
					<h1>404 NOT FOUND</h1>
				</div>
			</div>
			<div class="pro_all_gird">
				<div class="girds_all list_all_other_page ">
					<h3>
						Quay về<a href="<?php echo BASE_URL?>" style="color: blue;"> Trang Chủ!</a>
					</h3>
					<div class="clear"></div>
				</div>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
		</div>

	</div>
</section>
<!--end:body-->
<div class="clear"></div>