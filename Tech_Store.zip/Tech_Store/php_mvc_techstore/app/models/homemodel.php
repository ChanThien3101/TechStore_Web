<?php

class homemodel extends DModel
{

    public function __construct()
    {
        parent::__construct();
    }
}
?>