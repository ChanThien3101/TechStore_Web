<?php
    define('BASE_URL', 'http://localhost:8080/Nam2/Do_An_Mon/Tech_Store/php_mvc_techstore')
?>